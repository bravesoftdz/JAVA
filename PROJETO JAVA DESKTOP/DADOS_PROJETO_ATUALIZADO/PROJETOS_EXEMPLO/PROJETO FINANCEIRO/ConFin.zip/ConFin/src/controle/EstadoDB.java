/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Estado;

/**
 *
 * @author Marciel
 */
public class EstadoDB {
    private static final String SqlTodos = "SELECT * FROM estado";

    public ArrayList getTodos(){
        ArrayList listaEstado = new ArrayList();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try{
            conn = Conexao.getConexao();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SqlTodos);
            while(rs.next()){
                String est_sigla = rs.getString("est_sigla");
                String nome = rs.getString("nome");
                Estado estado = new Estado(est_sigla,nome);
                listaEstado.add(estado);
            }
        }catch(SQLException erro){
            System.out.println("Erro no sql, getTodos():"+erro.getMessage());
        }finally{
            Conexao.closeAll(conn);
        }
        return listaEstado;
    }
}
