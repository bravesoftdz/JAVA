/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import controle.EstadoDB;
import java.util.ArrayList;
import modelo.Estado;

/**
 *
 * @author Marciel
 */
public class TesteEstado {
    public static void main(String[] args) {
        EstadoDB estadodb = new EstadoDB();
        ArrayList<Estado> listaEstado = new ArrayList();
        listaEstado = estadodb.getTodos();        
        for(Estado auxEstado : listaEstado){
            System.out.println("Sigla: "+auxEstado.getEst_sigla());
            System.out.println("Nome: "+auxEstado.getNome());
        }
    }
}
